#include <stdio.h>
#include <stdlib.h>

char acFormatSaisie[] = "%d";
char acTxtSaisie[] = "Minutes en heures:min : ";

char acFormatAffichage[] = "%d min = %dh%dmin\n";



int iVar;


void main()
{

	_asm{
		
		push offset acTxtSaisie
		call dword ptr printf
		add esp, 4

		push offset iVar
		push offset acFormatSaisie
		call dword ptr scanf
		add esp, 8

		MOV			EAX, iVar
		MOV			EBX, 60
		CDQ
		IDIV		EBX

		push EDX
		push EAX
		push iVar
		push offset acFormatAffichage
		call dword ptr printf
		add esp, 16

	}

	system("pause");

	/*_asm
	{
		push offset acTxtSaisie
		call dword ptr printf
		add esp, 4

		push offset iVar
		push offset acFormatSaisie
		call dword ptr scanf
		add esp, 8

		mov eax, iVar
		add eax, iVar1

		push eax
		push iVar1
		push iVar
		push offset acFormatAffichage
		call dword ptr printf
		add esp, 16

	}*/

}