#include <stdio.h>
#include <stdlib.h>

char acFormatSaisie[] = "%d";
char acTxtSaisie[] = "Perimetre ? : ";

char acFormatAffichage[] = "Perimetre de %lfcm = %lf \n";
char acFormatAffichage2[] = "surface de %lfcm = %lf \n";

const double pi = 3.14;
const double MulSS2 = 2;
double result = 0;

int iVar;


void main()
{

	_asm{
		
		push offset acTxtSaisie
		call dword ptr printf
		add esp, 4

		push offset iVar
		push offset acFormatSaisie
		call dword ptr scanf
		add esp, 8


		CVTSI2SD	XMM0, iVar
		MOVSD		XMM1, MulSS2
		MULSD		XMM1, pi
		MULSD		XMM0, XMM1
		MOVSD		result, XMM0


		push iVar
		push dword ptr result + 4
		push dword ptr result
		push offset acFormatAffichage
		call dword ptr printf
		add esp, 16

		// party 2
		
		CVTSI2SD	XMM1, iVar
		MULSD		XMM1, XMM1
		MULSD		XMM1, pi
		MOVSD		result, XMM1


		push iVar
		push dword ptr result + 4
		push dword ptr result
		push offset acFormatAffichage2
		call dword ptr printf
		add esp, 16


	}

	system("pause");

	/*_asm
	{
		push offset acTxtSaisie
		call dword ptr printf
		add esp, 4

		push offset iVar
		push offset acFormatSaisie
		call dword ptr scanf
		add esp, 8

		mov eax, iVar
		add eax, iVar1

		push eax
		push iVar1
		push iVar
		push offset acFormatAffichage
		call dword ptr printf
		add esp, 16

	}*/

}