#include <stdio.h>
#include <stdlib.h>

char acFormatSaisie[] = "%d";
char acTxtSaisie[] = "Une temperature en C : ";

char acFormatAffichage[] = "%d deg. = %d Fara.";



int iVar;


void main()
{

	_asm{
		
		push offset acTxtSaisie
		call dword ptr printf
		add esp, 4

		push offset iVar
		push offset acFormatSaisie
		call dword ptr scanf
		add esp, 8

		MOV			EAX, iVar
		IMUL		EAX, 9
		CDQ
		MOV			EBX, 5
		IDIV		EBX
		ADD			EAX, 32


		
		push EAX
		push iVar
		push offset acFormatAffichage
		call dword ptr printf
		add esp, 12

	}

	system("pause");

	/*_asm
	{
		push offset acTxtSaisie
		call dword ptr printf
		add esp, 4

		push offset iVar
		push offset acFormatSaisie
		call dword ptr scanf
		add esp, 8

		mov eax, iVar
		add eax, iVar1

		push eax
		push iVar1
		push iVar
		push offset acFormatAffichage
		call dword ptr printf
		add esp, 16

	}*/

}