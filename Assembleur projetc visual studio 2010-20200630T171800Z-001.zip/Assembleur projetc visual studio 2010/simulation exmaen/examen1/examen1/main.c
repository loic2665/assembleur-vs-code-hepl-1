#include <stdio.h>


short s = 30;
float f = 20.6;
double d = 3;
float *pf = &f;
double *pd = &d;/*
*pd = *pf / (2 - d) - s; // d = -50.6000... */

int main(){


	_asm
	{
	
	MOV			EAX, 2
	CVTSI2SD	XMM0, EAX
	SUBSD		XMM0, d

	MOV			EAX, pf
	CVTSS2SD	XMM1, [EAX]

	DIVSD		XMM1, XMM0
	

	MOVSX		EAX, s
	CVTSI2SD	XMM2, EAX
	
	SUBSD		XMM1, XMM2

	MOV			EBX, pd
	MOVSD		[EBX], XMM1

	
	}

	return 0;
}