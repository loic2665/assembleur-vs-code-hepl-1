#include <stdio.h>


int iVar1;
char entre1str[] = "Entrez le chiffre 1: ";
char entre1scanf[] = "%d";


int iVar2;
char entre2str[] = "Entrez le chiffre 2: ";
char entre2scanf[] = "%d";


char inRange[] = "Dans le range !\n";
char notInRange[] = "Pas ans le range !\n";

int main(){


	_asm{
	
		push offset entre1str
		call dword ptr printf
		add esp, 4

		push offset iVar1
		push offset entre1scanf
		call dword ptr scanf
		add esp, 8
		// second nombre
		push offset entre2str
		call dword ptr printf
		add esp, 4

		push offset iVar2
		push offset entre2scanf
		call dword ptr scanf
		add esp, 8

		MOV EAX, iVar1
		MOV EBX, iVar2
		IMUL EAX, EBX

		cmp EAX, -50
		jg deuxiemeif
		jng notinrange

		deuxiemeif:
			
			cmp EAX, 50
			jg notinrange
			jng inrange

		notinrange:

			push offset notInRange
			call dword ptr printf
			add esp, 4
			jmp finif

		inrange:
			
			push offset inRange
			call dword ptr printf
			add esp, 4

		finif:

	}


}