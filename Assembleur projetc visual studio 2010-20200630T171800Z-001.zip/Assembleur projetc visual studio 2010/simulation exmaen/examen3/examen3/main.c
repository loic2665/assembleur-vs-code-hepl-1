#include <stdio.h>


int iVar1;
char entreStr[] = "Entrez le chiffre %d: ";
char entreScanf[] = "%d";
int i;
int iNeg = 0;

char nbNeg[] = "Nombre negatifs : %d\n";

int main(){


	_asm{


		MOV i, 1

		blocWhile:
			
			push i
			push offset entreStr
			call dword ptr printf
			add esp, 8

			push offset iVar1
			push offset entreScanf
			call dword ptr scanf
			add esp, 8

			CMP iVar1, 0

			JNG isNeg
			JG  finif

			isNeg:
				
				INC iNeg


			finif:

			INC i

			CMP i, 5
			JNG blocWhile
			JG  finWhile

		finWhile:

			
			push iNeg
			push offset nbNeg
			call dword ptr printf
			add esp, 8

	}
}