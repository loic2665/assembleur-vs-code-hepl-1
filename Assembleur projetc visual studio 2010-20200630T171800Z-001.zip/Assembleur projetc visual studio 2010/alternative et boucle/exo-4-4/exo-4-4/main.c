#include <stdio.h>

int curr = 0;
char input[] = "Entrez une val. quelconque : ";
char toInput[] = "%d";

char ok[] = "ok\n";
char horslimite[] = "sortir!\n";

int main(){


	

	_asm
	{


	whiledebut:
		
		cmp curr, -5
		jg secondif
		jng whilefin

		secondif:
			cmp curr, 5
			jg whilefin
			jng whilebloc

	whilebloc:

			
		push offset input
		call dword ptr printf
		add esp, 4

		
		push offset curr
		push offset toInput
		call dword ptr scanf
		add esp, 8
		
		jmp whiledebut

	whilefin:

		push offset horslimite
		call dword ptr printf
		add esp, 4

	}

	return 0;
}