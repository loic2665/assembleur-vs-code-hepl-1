#include <stdio.h>

int i;
int highest;
int curr;

char input[] = "Entrez la val. %d : ";
char nonok[] = "Valeur trop petite !\n";
char toInput[] = "%d";


int main(){

	//Produire une petite table de conversion euro vers franc (1 euro = 40,3399 francs) allant de
	//1 � 10 euros
	

	_asm
	{
	mov i, 1

	whiledebut:

		cmp i, 6
		jl whilebloc
		jnl whilefin

	whilebloc:
		
		push i
		push offset input
		call dword ptr printf
		add esp, 8

		
		push offset curr
		push offset toInput
		call dword ptr scanf
		add esp, 8

		ifdebut:
			mov EAX, curr
			cmp EAX, highest
			jg ifok
			jng ifnonok

		ifok:
			mov EAX, curr
			mov highest, EAX
			jmp finif

		ifnonok:
			push offset nonok
			call dword ptr printf
			add esp, 4
			jmp whilebloc

		finif:
			inc i
			jmp whiledebut

	whilefin:

	}

	return 0;
}