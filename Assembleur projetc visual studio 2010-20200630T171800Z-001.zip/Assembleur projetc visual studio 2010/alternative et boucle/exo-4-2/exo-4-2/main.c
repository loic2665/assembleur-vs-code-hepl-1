#include <stdio.h>

int i;
const double taux = 40.3399;
double res  = 0.0;
char format[] = "%d * 40.3399 = %lf\n";

int main(){

	//Produire une petite table de conversion euro vers franc (1 euro = 40,3399 francs) allant de
	//1 � 10 euros
	

	_asm
	{
	mov i, 1

	whiledebut:

		cmp i, 10
		jl whilebloc
		jnl whilefin

	whilebloc:

		cvtsi2sd xmm0, i
		movsd xmm1, xmm0
		mulsd xmm1, taux
		movsd res, xmm1

		
		push dword ptr res + 4
		push dword ptr res
		push i
		push offset format
		call dword ptr printf
		add esp, 16
		inc i
		jmp whiledebut

	whilefin:

	}

	return 0;
}